#백준
#2163번 초콜릿 자르기

a,b = map(int, input().split())

print(a*b-1)
